﻿=== UwU And OwO Cursor Set ===

By: Xx-DaveSils-xX (http://www.rw-designer.com/user/110559) dhayvie@yahoo.com

Download: http://www.rw-designer.com/cursor-set/uwu-and-owo

Author's description:

This was originally for a friend but I decided to release it to public bc am lazy. So you can take this if you want. If you decide to copy it please don't and copy someone's else's art ok? (The folllowing is for keywords) UwU OwO

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.