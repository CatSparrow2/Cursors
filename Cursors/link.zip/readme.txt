﻿=== Link Cursor Set ===

By: Frangel ッ (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/link

Author's description:

 Link Cursors, Sprites From "Sprites Resource"

 The Legend Zelda: Ocarina Of Time

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.