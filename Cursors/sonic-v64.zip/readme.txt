﻿=== Sonic the Hedgehog Cursor Set ===

By: Virum64 (http://www.rw-designer.com/user/30267) virum64@gmail.com

Download: http://www.rw-designer.com/cursor-set/sonic-v64

Author's decription:

[[image:rsrc/madeinfrance.png]]

A Sonic cursor set. Sprites ripped by Kevin Huff (Sonic sprites from Sonic Advance) and Frario (Chaos emerald).

Visit my [[image:rsrc/facebook_button.png]] page  [https://www.facebook.com/Virum64cursordesigner/ here].

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.