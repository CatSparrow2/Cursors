﻿=== Yugi Moto Cursor Set ===

By: Frangel ッ (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/yu-gi-oh

Author's description:

 Yugi Moto Cursors, Sprites From "Sprites Resource"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.