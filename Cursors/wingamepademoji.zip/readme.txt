﻿=== Windows Gamepad Emoji Cursor Set ===

By: Animelove_1105 (http://www.rw-designer.com/user/105799) joaquinuc1105@gmail.com

Download: http://www.rw-designer.com/cursor-set/wingamepademoji

Author's description:

== ONE THOUSAND DOWNLOADS!!!! ==
'''Thank you guys so much for the support you've given me within the past 10 months! Hope you look forward to upcoming sets! :)'''

'''This is an entry for the [[forum/6617|January 2023 ToTM Contest]]!'''

Hey everyone! I thought I might try out the ToTM contest, so I made this set! This cursor set uses the Gamepad (Or game controller) Emoji in the Windows 10 style. This also uses similar styled cursors too. I hope you enjoy these!

=== If there are any issues, please contact me! ===
'''Please do not reupload these and/or claim these as your own work.'''

Enjoy the set!
-❤ Animelove_1105

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.