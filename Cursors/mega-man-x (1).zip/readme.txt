﻿=== Mega Man X Cursor Set ===

By: Frangel ッ (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/mega-man-x

Author's description:

 "Mega Man X Cursors", Sprites from "Sprites Resource"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.