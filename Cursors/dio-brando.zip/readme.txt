﻿=== Dio Brando Cursor Set ===

By: Frangel ッ (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/dio-brando

Author's description:

 "Dio Brando Cursors", Sprites from "Sprites Resource"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.