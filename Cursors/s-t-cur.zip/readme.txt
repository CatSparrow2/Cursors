﻿=== Sonic & Tails Cursor Set ===

By: GamerestBoi (http://www.rw-designer.com/user/107801) ela.84@poczta.fm

Download: http://www.rw-designer.com/cursor-set/s-t-cur

Author's description:

The duo on ya' screen for all time!
Note: please make the cursor bigger in the settings, it will make you see more details in it.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.