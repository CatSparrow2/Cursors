﻿=== Sonic Pocket Adventure - Knuckles Cursor Set ===

By: eeveelover64 (http://www.rw-designer.com/user/79116) eeveelovr64@gmail.com

Download: http://www.rw-designer.com/cursor-set/knuckles-pocket-adventure

Author's description:

= THIS WAS MADE FOR THE [http://www.rw-designer.com/forum/6617/ 2023 TOTM OF JANUARY] =

y'know the time i said i wouldn't be making knuckles pocket adventure cursors in my [http://www.rw-designer.com/cursor-set/tails-pocket-adventure tails pocket adventure cursor set?] well... thanks to [https://www.youtube.com/@sonicfan2144/ SonicFan214#8429's] help, i was able to make this set! so, shoutouts to him! btw og insiration is from [http://www.rw-designer.com/cursor-set/spa-by-piggeh/ this set]

Cursor set made by me using [https://store.steampowered.com/app/431730/Aseprite/ Aseprite] and [http://www.rw-designer.com/cursor-maker/ RWCursor Editor]
Handwriting was made by [https://www.youtube.com/@kittykata12theyoutuber27 KittyKata12#2023]: http://www.rw-designer.com/user/73016,

Sources used: 

https://www.spriters-resource.com/neo_geo_pocket/sonicpocketadventure/sheet/5993/
https://gamebanana.com/mods/169169
https://twitter.com/vadepega/status/1372768404143140870?lang=en
http://vgmrips.net/misc/SonicPocketWinter.7z

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.