﻿=== One Dark Pro Space Invaders Cursor Set ===

By: The Derpy Girl (http://www.rw-designer.com/user/55973)

Download: http://www.rw-designer.com/cursor-set/one-dark-pro-space-invaders

Author's description:

Space invaders cursors for One Dark Pro theme for Windows 11 22H2 from https://www.deviantart.com/niivu/art/One-Dark-Pro-for-Windows-11-22H2-930312689.

This is also for January\'s TOTM Contest of 2023. See this forum post for details: http://www.rw-designer.com/forum/6617

Great for the dark theme.

Enjoy! :)

==========

License: Creative Commons - Attribution + Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.
* Noncommercial - You may not use this work for commercial purposes.